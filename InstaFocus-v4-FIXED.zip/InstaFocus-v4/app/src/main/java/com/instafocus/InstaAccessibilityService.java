package com.instafocus;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class InstaAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM = "com.instagram.android";
    private static final Object REFRESH_TOKEN = new Object();

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<BlockView> views = new ArrayList<>();
    private android.content.SharedPreferences prefs;

    private boolean instagramForeground;
    private Mode mode = Mode.NONE;
    private boolean searchHasQuery;
    private boolean allowSharedViewer;
    private long lastStrongModeAt;
    private OverlaySpec lastApplied = OverlaySpec.none();

    private enum Mode { NONE, HOME, REELS, SEARCH, MESSAGES, OTHER }

    private static final class OverlaySpec {
        final Kind kind;
        final boolean quote;
        final int width;
        final int height;
        enum Kind { NONE, HOME, REELS, SEARCH }
        OverlaySpec(Kind k, boolean q, int w, int h) { kind=k; quote=q; width=w; height=h; }
        static OverlaySpec none() { return new OverlaySpec(Kind.NONE,false,0,0); }
        @Override public boolean equals(Object o) {
            if (!(o instanceof OverlaySpec)) return false;
            OverlaySpec x=(OverlaySpec)o;
            return kind==x.kind && quote==x.quote && width==x.width && height==x.height;
        }
        @Override public int hashCode() { return (((kind.hashCode()*31)+(quote?1:0))*31+width)*31+height; }
    }

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            setServiceInfo(info);
        }
        // If Instagram is already open when the service is enabled, seed HOME immediately.
        AccessibilityNodeInfo root = getRootInActiveWindow();
        instagramForeground = root != null && INSTAGRAM.equals(String.valueOf(root.getPackageName()));
        if (instagramForeground) {
            mode = Mode.HOME;
            lastStrongModeAt = SystemClock.uptimeMillis();
            applyOverlay(desiredOverlaySpec());
        }
        scheduleRefresh(180);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence packageName = event.getPackageName();
        String pkg = packageName == null ? "" : packageName.toString();

        // Ignore events produced by InstaFocus itself.
        if (getPackageName().equals(pkg)) return;

        if (!INSTAGRAM.equals(pkg)) {
            if (instagramForeground) {
                instagramForeground = false;
                mode = Mode.NONE;
                searchHasQuery = false;
                allowSharedViewer = false;
                applyOverlay(OverlaySpec.none());
            }
            return;
        }

        instagramForeground = true;

        // Critical fallback: never wait for Instagram's accessibility tree to expose
        // the Home label. If no mode is known, block Home immediately, then refine.
        if (mode == Mode.NONE || mode == Mode.OTHER) {
            mode = Mode.HOME;
            allowSharedViewer = false;
            applyOverlay(desiredOverlaySpec());
        }
        scheduleRefresh(160);
    }

    @Override public void onInterrupt() { }

    private void scheduleRefresh(long delay) {
        handler.removeCallbacksAndMessages(REFRESH_TOKEN);
        handler.postAtTime(this::refresh, REFRESH_TOKEN, SystemClock.uptimeMillis()+delay);
    }

    private void refresh() {
        if (!instagramForeground) return;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        State state = detectMode(root);

        long now = SystemClock.uptimeMillis();
        // IMPORTANT: never fall back from a confidently detected Reels/Search/Messages
        // screen to Home just because one accessibility snapshot is incomplete.
        // Instagram frequently publishes partial trees while a screen is animating.
        if (state.mode != Mode.NONE) {
            if (state.mode == Mode.REELS || state.mode == Mode.SEARCH || state.mode == Mode.MESSAGES || state.mode == Mode.HOME) {
                if (state.mode == Mode.REELS && mode == Mode.MESSAGES) {
                    allowSharedViewer = true;
                } else if (state.mode != Mode.REELS) {
                    allowSharedViewer = false;
                }
                if (state.mode != mode) {
                    lastStrongModeAt = now;
                }
                mode = state.mode;
            }
            searchHasQuery = state.query;
        }

        applyOverlay(desiredOverlaySpec());
        scheduleRefresh(350);
    }

    private OverlaySpec desiredOverlaySpec() {
        int w=getResources().getDisplayMetrics().widthPixels;
        int h=getResources().getDisplayMetrics().heightPixels;
        if (prefs == null) prefs=getSharedPreferences("settings",MODE_PRIVATE);
        switch(mode) {
            case HOME:
                return prefs.getBoolean("home",true) ? new OverlaySpec(OverlaySpec.Kind.HOME,false,w,h) : OverlaySpec.none();
            case REELS:
                return prefs.getBoolean("reels",true) && !allowSharedViewer ? new OverlaySpec(OverlaySpec.Kind.REELS,false,w,h) : OverlaySpec.none();
            case SEARCH:
                return prefs.getBoolean("search",true) && !searchHasQuery
                        ? new OverlaySpec(OverlaySpec.Kind.SEARCH,prefs.getBoolean("quote",true),w,h)
                        : OverlaySpec.none();
            default:
                return OverlaySpec.none();
        }
    }

    private static final class State {
        final Mode mode;
        final boolean query;
        State(Mode m, boolean q) { mode=m; query=q; }
    }

    private State detectMode(AccessibilityNodeInfo root) {
        if (root == null) return new State(Mode.NONE, searchHasQuery);
        List<AccessibilityNodeInfo> nodes=new ArrayList<>();
        collect(root,nodes,0);

        boolean reels=false, search=false, messages=false, home=false, query=false;
        for (AccessibilityNodeInfo n:nodes) {
            String raw=n.getText()==null?"":n.getText().toString().trim();
            String cd=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();
            String t=(raw+" "+cd).toLowerCase(Locale.ROOT);

            if (t.equals("reels") || t.contains("reels tab") || t.contains("reels, selected") || (t.contains("reels") && n.isSelected())) reels=true;
            if (t.equals("search") || t.contains("search and explore") || t.contains("search tab") || t.contains("search, selected")) search=true;
            if (t.equals("home") || t.contains("home tab") || t.contains("home, selected")) home=true;
            if (t.contains("messages") || t.contains("direct messages") || t.contains("messenger") || t.contains("inbox")) messages=true;
            if (n.isEditable() && !raw.isEmpty()) query=true;
        }

        // Prefer screens with distinctive content. Do NOT use Home as a fallback
        // here: persistent Home navigation nodes exist on several Instagram screens.
        if (reels && likelyReels(nodes)) return new State(Mode.REELS, false);
        if (search && likelySearch(nodes)) return new State(Mode.SEARCH, query);
        if (messages && likelyMessages(nodes)) return new State(Mode.MESSAGES, false);
        if (home && likelyHome(nodes)) return new State(Mode.HOME, query);

        // No confident identification. Keep the previous mode. This prevents the
        // Reels blocker from disappearing during swipe/load animations.
        return new State(mode == Mode.NONE ? Mode.HOME : mode, query);
    }

    private boolean likelyHome(List<AccessibilityNodeInfo> nodes) {
        for (AccessibilityNodeInfo n:nodes) {
            String t=text(n);
            if (t.contains("your story") || t.contains("create story") || t.contains("add to story")) return true;
        }
        return true;
    }

    private boolean likelyReels(List<AccessibilityNodeInfo> nodes) {
        int c=0;
        for (AccessibilityNodeInfo n:nodes) {
            String t=text(n);
            if (t.contains("reels") || t.contains("likes") || t.contains("comments") || t.contains("audio") || t.contains("share")) c++;
        }
        return c >= 1;
    }

    private boolean likelySearch(List<AccessibilityNodeInfo> nodes) {
        for (AccessibilityNodeInfo n:nodes) {
            String t=text(n);
            if (t.contains("search") && (n.isFocused() || n.isEditable())) return true;
        }
        for (AccessibilityNodeInfo n:nodes) {
            String t=text(n);
            if (t.contains("for you") || t.contains("recent searches") || t.contains("suggested for you")) return true;
        }
        return false;
    }

    private boolean likelyMessages(List<AccessibilityNodeInfo> nodes) {
        int c=0;
        for (AccessibilityNodeInfo n:nodes) {
            String t=text(n);
            if (t.contains("message") || t.contains("chat") || t.contains("inbox")) c++;
        }
        return c >= 2;
    }

    private String text(AccessibilityNodeInfo n) {
        String a=n.getText()==null?"":n.getText().toString();
        String b=n.getContentDescription()==null?"":n.getContentDescription().toString();
        return (a+" "+b).toLowerCase(Locale.ROOT);
    }

    private void collect(AccessibilityNodeInfo node,List<AccessibilityNodeInfo> out,int depth) {
        if (depth>20 || out.size()>600) return;
        out.add(node);
        for(int i=0;i<node.getChildCount();i++) {
            AccessibilityNodeInfo c=node.getChild(i);
            if(c!=null) collect(c,out,depth+1);
        }
    }

    private void applyOverlay(OverlaySpec spec) {
        // This is the anti-blink guard: if nothing changed, leave existing Views alone.
        if (spec.equals(lastApplied)) return;
        clearOverlays();
        lastApplied=spec;
        if(spec.kind==OverlaySpec.Kind.NONE) return;

        switch(spec.kind) {
            case HOME:
                // Stories remain visible; everything from just below the story row
                // through the feed is covered with an opaque Instagram-like surface.
                addBlock(0,(int)(spec.height*.215f),spec.width,(int)(spec.height*.915f),"home-feed",false);
                // Instagram's Reels tab is the fourth item on the 5-item bottom bar.
                addBlock((int)(spec.width*.60f),(int)(spec.height*.905f),(int)(spec.width*.80f),spec.height,"reels-nav",false);
                break;
            case REELS:
                // Full-screen opaque blocker. No translucent gap means repeated swipes
                // cannot reveal the Reel underneath.
                addBlock(0,0,spec.width,spec.height,"reels-full",false);
                break;
            case SEARCH:
                // Leave the search field itself usable. Cover the suggestion/results
                // region with an opaque surface rather than a translucent view.
                addBlock(0,(int)(spec.height*.16f),spec.width,(int)(spec.height*.58f),"search-suggestions",spec.quote);
                break;
            default: break;
        }
    }

    private void addBlock(int left,int top,int right,int bottom,String id,boolean quote) {
        if(right<=left || bottom<=top) return;
        WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        BlockView view=new BlockView(this,quote);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(
                right-left,bottom-top,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.START;
        p.x=left;
        p.y=top;
        p.setTitle("InstaFocus:"+id);
        try {
            wm.addView(view,p);
            views.add(view);
        } catch(Exception ignored) { }
    }

    private void clearOverlays() {
        WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        for(BlockView v:new ArrayList<>(views)) {
            try { wm.removeViewImmediate(v); } catch(Exception ignored) { }
        }
        views.clear();
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(REFRESH_TOKEN);
        clearOverlays();
        super.onDestroy();
    }

    private class BlockView extends View {
        private final boolean drawQuote;
        private float downX,downY;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);

        BlockView(android.content.Context c,boolean q) {
            super(c);
            drawQuote=q;
            setClickable(true);
            boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
            // Opaque surface: Instagram content must not bleed through while blocked.
            setBackgroundColor(dark ? Color.rgb(10,10,10) : Color.rgb(250,250,250));
            setOnTouchListener((v,e)-> { handleTouch(e); return true; });
        }

        private void handleTouch(MotionEvent e) {
            if(mode==Mode.REELS && !allowSharedViewer) {
                if(e.getActionMasked()==MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY();
                } else if(e.getActionMasked()==MotionEvent.ACTION_UP) {
                    float dx=e.getRawX()-downX;
                    float dy=Math.abs(e.getRawY()-downY);
                    if(downX<70f && dx>110f && dy<140f) performGlobalAction(GLOBAL_ACTION_BACK);
                }
            }
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if(!drawQuote) return;
            boolean dark=(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES;
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(android.graphics.Typeface.create("sans",android.graphics.Typeface.NORMAL));
            paint.setColor(dark?Color.WHITE:Color.rgb(25,25,28));
            float cx=getWidth()/2f;
            paint.setTextSize(Math.max(25f,Math.min(40f,getWidth()*.052f)));
            canvas.drawText("Protect your attention.",cx,getHeight()*.43f,paint);
            paint.setTextSize(Math.max(18f,Math.min(27f,getWidth()*.036f)));
            canvas.drawText("Search with purpose, then leave.",cx,getHeight()*.58f,paint);
            paint.setColor(Color.rgb(131,58,180));
            paint.setTextSize(Math.max(17f,Math.min(25f,getWidth()*.033f)));
            canvas.drawText("InstaFocus",cx,getHeight()*.75f,paint);
        }
    }
}
